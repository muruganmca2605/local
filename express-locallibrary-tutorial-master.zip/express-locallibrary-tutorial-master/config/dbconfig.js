const mongoose = require("mongoose");
require("dotenv").config();
var indexRouter = require('../routes/index');
var usersRouter = require('../routes/users');
var catalogRouter = require('../routes/catalog');
mongoose.connect(process.env.DB_URI, { useNewUrlParser: true });

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", function() {
  console.log("Connection established");
});